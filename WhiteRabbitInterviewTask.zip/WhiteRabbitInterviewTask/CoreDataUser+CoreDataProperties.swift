//
//  CoreDataUser+CoreDataProperties.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//
//

import Foundation
import CoreData


extension CoreDataUser {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CoreDataUser> {
        return NSFetchRequest<CoreDataUser>(entityName: "CoreDataUser")
    }

    @NSManaged public var name: String?
    @NSManaged public var id: Int32
    @NSManaged public var username: String?
    @NSManaged public var email: String?
    @NSManaged public var profile_image: String?
    @NSManaged public var addressStreet: String?
    @NSManaged public var addressSuite: String?
    @NSManaged public var addressCity: String?
    @NSManaged public var addressZipcode: String?
    @NSManaged public var phone: String?
    @NSManaged public var website: String?
    @NSManaged public var companyName: String?
    @NSManaged public var companyCatchPhrase: String?
    @NSManaged public var companyBs: String?

}

extension CoreDataUser : Identifiable {

}
