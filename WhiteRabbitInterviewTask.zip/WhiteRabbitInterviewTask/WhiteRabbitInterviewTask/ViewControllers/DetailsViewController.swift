//
//  DetailsViewController.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//

import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var emailAddressLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var websiteLabel: UILabel!
    @IBOutlet weak var companyNameLabel: UILabel!
    
    var data : CoreDataUser?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        setData()
    }
    
    
    private func setData(){
        profileImageView.loadImageUsingCache(withUrl: data?.profile_image ?? "")
        nameLabel.text = data?.name ?? ""
        userNameLabel.text = data?.username ?? ""
        emailAddressLabel.text = data?.email ?? ""
        addressLabel.text = "\(data?.addressStreet ?? "") ,\(data?.addressCity ?? "") ,\(data?.addressSuite ?? "") ,\(data?.addressZipcode ?? "")"
        phoneLabel.text = data?.phone ?? ""
        websiteLabel.text = data?.website ?? ""
        companyNameLabel.text = "\(data?.companyName ?? "") ,\(data?.addressSuite ?? "") ,\(data?.addressZipcode ?? "")"

        
        
    }
}
