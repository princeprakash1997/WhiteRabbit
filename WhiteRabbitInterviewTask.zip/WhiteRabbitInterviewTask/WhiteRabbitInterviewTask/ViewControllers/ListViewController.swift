//
//  ViewController.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//

import UIKit

class ListViewController: UIViewController {

    @IBOutlet weak var userTableView: UITableView!
    @IBOutlet weak var userSearchBar: UISearchBar!
    
    
    let viewModel = ListViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        initialLoads()
    }


}

// MARK:- Initial Functions

extension ListViewController {
    
    private func initialLoads(){
        setText()
        setColor()
        setFont()
        registetNib()
        setDelegate()
        AddTarget()
        initialAPI()
    }
    
    private func setText(){
        userSearchBar.placeholder = "search user ... "
        userSearchBar.searchTextField.font = UIFont.systemFont(ofSize: 10)
    }
    
    private func setColor(){
        
    }
    
    private func setFont(){
        
    }
    
    private func setDelegate(){
        userTableView.delegate = self
        userTableView.dataSource = self
        userTableView.separatorStyle = .none
        userTableView.backgroundColor = .white
    }
    
    private func registetNib(){
        userTableView.register(UINib(nibName: "UserTableViewCell", bundle: .main), forCellReuseIdentifier: "UserTableViewCell")
    }
    
    private func AddTarget(){
        userSearchBar.searchTextField.addTarget(self, action: #selector(textChanged(sender:)), for: .editingChanged)
    }
    
    private func initialAPI(){
        viewModel.getUser {
            self.userTableView.reloadData()
        }
    }
    
    @objc func textChanged(sender: UITextField){
        viewModel.searchList(text: sender.text ?? "") {
            self.userTableView.reloadData()
        }
    }
    
}



// MARK: - TableView Functions

extension ListViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberofCell()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return viewModel.getCell(tableview: tableView, index: indexPath)
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        vc.data = viewModel.getdata(index: indexPath)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
