//
//  WebService.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//

import Foundation


import Foundation
import Alamofire



class WebService {
    
    static let shared = WebService()
    
    
    func getuser(completion: @escaping(Data) -> (),errorCompletion: @escaping(String) -> ()){
        
        // Headers
        var headers = HTTPHeaders()
        //        headers.update(name:WebConstants.string.Content_Type, value:WebConstants.string.application_json)
//        headers.update(name:WebConstants.string.X_Requested_With, value:WebConstants.string.XMLHttpRequest)
//        if isAuthNeeded {
//            if let accessToken = UserDefaults.standard.string(forKey: "accessToken"){
//                print("Access Token ---\(accessToken)")
//                headers.update(name:WebConstants.string.Authorization, value: "\(WebConstants.string.bearer) \(accessToken)")
//            }
//        }
        
        AF.request(userlisturl, method: .get, parameters: nil, headers: headers).responseJSON{ response in
            print("response.result",response.result)
            
            switch response.result {
            case .failure:
                print("ERROR---\(response.error?.localizedDescription ?? "API ERROR")")
                errorCompletion(response.error?.localizedDescription ?? "API ERROR")
                
            case .success:
                print("RESPONSE---\(response.value)")
                if let data = response.data {
                    completion(data)
                }
            }
        }
        
    }
    
}

