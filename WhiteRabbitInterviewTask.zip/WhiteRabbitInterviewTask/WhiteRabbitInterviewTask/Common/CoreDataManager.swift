//
//  CoreDataManager.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//

import Foundation
import CoreData
import UIKit


class CoreDataManager {
    
    static let shared = CoreDataManager()
    
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    private init() {}
    
    
    func saveEmployes(users:[User]) {
        for user in users {
            let cuser = CoreDataUser(context:context!)
            cuser.name = user.name
            cuser.email = user.email
            cuser.profile_image = user.profile_image
            cuser.companyName = user.company?.name
            cuser.username = user.username
            cuser.addressCity = user.address?.city
            cuser.addressSuite = user.address?.suite
            cuser.addressStreet = user.address?.street
            cuser.addressZipcode = user.address?.zipcode
            cuser.phone = user.phone
            cuser.website = user.website
            cuser.companyBs = user.company?.bs
            cuser.companyCatchPhrase = user.company?.catchPhrase
            try? context?.save()
        }
    }
    
    func fetchEmployes() -> [CoreDataUser]? {
        let req = CoreDataUser.fetchRequest()
        let obj = try? context?.fetch(req)
        return obj
    }
}
