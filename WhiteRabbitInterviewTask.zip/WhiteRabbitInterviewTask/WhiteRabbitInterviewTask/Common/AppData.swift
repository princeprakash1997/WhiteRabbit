//
//  AppData.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//

import Foundation


let userlisturl = "https://www.mocky.io/v2/5d565297300000680030a986"
