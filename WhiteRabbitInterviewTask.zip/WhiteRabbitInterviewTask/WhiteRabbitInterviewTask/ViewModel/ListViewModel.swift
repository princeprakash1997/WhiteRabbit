//
//  ListViewModel.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//

import Foundation
import UIKit


class ListViewModel{
    
    
    
    private var userList = [CoreDataUser]()
    private var searchList = [CoreDataUser]()
    // MARK:-  UI Functions
    
    
    func getNumberofCell() -> Int{
        return searchList.count
    }
    
    
    func getdata(index: IndexPath) -> CoreDataUser {
        return searchList[index.row]
    }
    
    func getCell(tableview: UITableView, index: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "UserTableViewCell", for: index) as! UserTableViewCell
        let data = searchList[index.row]
        cell.selectionStyle = .none
        cell.profileImageView.loadImageUsingCache(withUrl: data.profile_image ?? "")
        cell.nameLabel.text = data.name ?? ""
        cell.companyNameLabel.text = data.companyName ?? ""
        return cell
    }
    
    func searchList(text: String,completion :@escaping() -> ()){
        
        if text == "" {
            self.searchList = self.userList
            completion()
        }
        else{
            self.searchList = [CoreDataUser]()
            for i in self.userList {
                if (i.name ?? "").uppercased().contains(text.uppercased()) || (i.companyName ?? "").uppercased().contains(text.uppercased()){
                    self.searchList.append(i)
                }
            }
            completion()
        }
    }
    
    // MARK:-  Data Functions
    
    
    
    // MARK:-  API Functions
    
    func getUser(completion :@escaping() -> ()){
        
        if (CoreDataManager.shared.fetchEmployes() ?? [CoreDataUser]()).count != 0 {
            self.userList = (CoreDataManager.shared.fetchEmployes() ?? [CoreDataUser]())
            self.searchList = self.userList
            completion()
        }
        else{
        WebService.shared.getuser { data in
            do{
              let jsonDecoder = JSONDecoder()
              let responseModel = try jsonDecoder.decode([User].self, from: data)
                print(responseModel)
                CoreDataManager.shared.saveEmployes(users: responseModel)
                self.userList = CoreDataManager.shared.fetchEmployes() ?? [CoreDataUser]()
                self.searchList = self.userList
                completion()
            }
            catch{
                
            }
        } errorCompletion: { error in
            
            
        }
      }
    }
    
    
}
