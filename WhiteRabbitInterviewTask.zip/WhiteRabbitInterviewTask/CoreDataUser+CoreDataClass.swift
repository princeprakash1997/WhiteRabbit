//
//  CoreDataUser+CoreDataClass.swift
//  WhiteRabbitInterviewTask
//
//  Created by Apple on 20/08/22.
//
//

import Foundation
import CoreData

@objc(CoreDataUser)
public class CoreDataUser: NSManagedObject {

}
